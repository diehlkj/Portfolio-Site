window.onload = function hideLoad() {
    document.getElementById('loading').style.display = 'none';
}